# IHRAR RIDES — Flutter Starter

This is the first coding foundation for the IHRAR RIDES project.

## What is included
- Flutter project manifest
- Urdu + English locale foundation
- First language-selection screen
- IHRAR RIDES logo asset
- Development plan with the decisions already agreed

## Run later when Flutter is installed

```bash
flutter pub get
flutter run
```

## Next
Firebase authentication, OTP, maps/GPS, fare negotiation, driver app, admin panel, commission ledger, and security rules will be added in separate milestones.
