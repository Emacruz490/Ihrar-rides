# IHRAR RIDES — Initial Architecture

Passenger App (Flutter)
        |
        v
IHRAR Backend / Firebase
        |
        +-- Authentication / OTP
        +-- Firestore database
        +-- Cloud Functions
        +-- Push notifications
        +-- Storage
        |
        +-- Maps/GPS provider
        +-- Pakistan SMS gateway
        +-- Payment provider
        |
        +-- Driver App (Flutter)
        +-- Admin Web Panel

The backend is the source of truth for ride status, fare offers, final fare, driver commission, 180-ride progress, fixed-plan status, and audit records.
