# IHRAR RIDES — Development Plan

## Current milestone
Passenger app foundation only. The logo supplied by the owner is included as the current brand asset.

## Locked product decisions
- Brand: IHRAR RIDES
- Passenger language: Urdu + English
- Driver language: Urdu + English
- Admin panel: English-first, Urdu-ready
- Fare model: passenger makes an offer; multiple drivers can accept or counter; passenger selects the final driver/fare.
- Driver plan: first 180 successful rides at 7%; after that, driver chooses 8% commission or Rs. 4,000 monthly fixed plan.
- Passenger sharing: reserved in the architecture for Version 2; not active in Version 1.
- Normal ride notifications: push notifications rather than SMS where possible.
- OTP: local Pakistan SMS gateway integration to be added later.
- Maps/GPS: Google Maps integration to be added after the foundation is stable.

## Next coding milestones
1. Passenger login/OTP UI and authentication service interface.
2. Home/map screen.
3. Pickup + destination selection.
4. Passenger fare offer creation.
5. Driver offer/counter-offer matching backend.
6. Driver app.
7. Ride PIN and live ride state machine.
8. Wallet/commission ledger.
9. Admin panel.
10. Firebase security rules and production hardening.

## Important
This starter project does not yet connect to Firebase, Maps, OTP, payments, or production APIs. Those integrations will be added deliberately rather than hard-coded into the first screen.
