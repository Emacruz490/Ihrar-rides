import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() {
  runApp(const IhrarRidesApp());
}

class IhrarRidesApp extends StatefulWidget {
  const IhrarRidesApp({super.key});

  @override
  State<IhrarRidesApp> createState() => _IhrarRidesAppState();
}

class _IhrarRidesAppState extends State<IhrarRidesApp> {
  Locale _locale = const Locale('ur');

  void setLanguage(Locale locale) => setState(() => _locale = locale);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'IHRAR RIDES',
      locale: _locale,
      supportedLocales: const [Locale('ur'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF173B52)),
      ),
      home: LanguageScreen(onLanguageSelected: setLanguage),
    );
  }
}

class LanguageScreen extends StatelessWidget {
  final ValueChanged<Locale> onLanguageSelected;
  const LanguageScreen({super.key, required this.onLanguageSelected});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/images/ihrar_rides_logo.png', height: 190),
                const SizedBox(height: 24),
                const Text('Choose Language', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () => onLanguageSelected(const Locale('ur')),
                    child: const Text('اردو', style: TextStyle(fontSize: 20)),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () => onLanguageSelected(const Locale('en')),
                    child: const Text('English', style: TextStyle(fontSize: 18)),
                  ),
                ),
                const SizedBox(height: 28),
                const Text(
                  'Chalo, Har Safar Ko Faide Ka Bana Do.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 15),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
